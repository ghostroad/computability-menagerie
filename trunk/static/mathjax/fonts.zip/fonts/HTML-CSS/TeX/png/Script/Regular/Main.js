/*
 *  /MathJax/fonts/HTML-CSS/TeX/png/Script/Regular/Main.js
 *  
 *  Copyright (c) 2010 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Unpack([
  ['MathJax.OutputJax["HTML-CSS"].','defineImageData({MathJax_Script:{}});MathJax.Ajax.loadComplete(',0,'imgDir+"/Script/Regular"+',0,'imgPacked+"/Main.js");']
]);

